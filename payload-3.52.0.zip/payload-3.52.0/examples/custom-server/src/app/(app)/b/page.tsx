export default function B() {
  return <div>b</div>
}
