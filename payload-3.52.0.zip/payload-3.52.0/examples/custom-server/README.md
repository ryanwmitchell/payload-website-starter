# Payload 3 with Custom Server

Run the following command to create a project from the example:

- `npx create-payload-app --example custom-server`

Uses a [Next.js Custom Server](https://nextjs.org/docs/pages/building-your-application/configuring/custom-server) with express.

Made from official [examples/custom-server](https://github.com/vercel/next.js/tree/canary/examples/custom-server) from Next.js repository.
